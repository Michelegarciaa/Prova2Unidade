package br.ifs.metodosEstaticos;

public class TestCalc {
  
  public static void main(String[] args) {
    double num1 = 4;
    double num2 = 2;
    
    System.out.println("Para num1 = " + num1 + " e num2 = " + num2);
    System.out.println("Soma = " + Calculadora.soma(num1, num2));
    System.out.println("Subtração = " + Calculadora.subtracao(num1, num2));
    System.out.println("Multiplicação = " + Calculadora.multiplicacao(num1, num2));
    System.out.println("Divisão = " + Calculadora.divisao(num1,num2));
   
   
    
  }
}
  
  
  
  
