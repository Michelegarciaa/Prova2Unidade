package br.ifs.heranca;

public class Teste {
  public static void main(String[] args) {
    float[] nAlu1 = {7f, 8f, 6f, 5f};
    Aluno alu1 = new Aluno("Joao Lero", nAlu1);
    
    float[] nAlu2 = {4f, 9f, 5f, 10f};
    Aluno alu2 = new Aluno("Maria Linda", nAlu2);
    
    Professor prof1 = new Professor();
    prof1.setNome("Raimundo");
    prof1.setMatricula("1212");
    prof1.setCpf("777777777");
    prof1.setSalario(5000);
    
    System.out.println("Aluno: " + alu1.getNome());
    for (float n1 : nAlu1){
      System.out.println("Nota: " + n1);
    }
    System.out.println("Aluno: " + alu2.getNome());
    for (float n2 : nAlu2){
      System.out.println("Nota: " + n2);
    }
    
    System.out.println("Professor: " + prof1.getNome());
    System.out.println("Salário: " + prof1.getSalario());
    
    
  }
}
  