package br.ifs.heranca;

public class Aluno extends Pessoa{
  
  private String matricula;
  private float[] notas;
  
  public Aluno(String matricula, float[] notas){
    this.matricula = matricula;
    this.notas = notas;
  }
  
  public String getMatricula(){
    return matricula;
  }
  
  public void setMatricula(String matricula){
    this.matricula = matricula;
  } 
  
  public float[] getNotas(){
    return notas;
  }
  
  public void setNotas(float[] notas){
    this.notas = notas;
  } 
  
  
}